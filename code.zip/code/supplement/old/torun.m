clc;
clear all;


% AOA_param(number of iterations,number of capacitors,upper limit cpacity,lower limit capacity)
for i=1:10
    
  AOA_param(100,3,1200,500)
end 